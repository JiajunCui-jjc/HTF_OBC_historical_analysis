# split multi-fasta into per-record fasta files named by the first token in header
awk '
BEGIN{ out="" }
(/^>/){
  id=$1
  sub(/^>/,"",id)          # remove leading ">"
  out = id ".fasta"
}
{
  if(out!="") print > out
}
' nucHTF_7refs.fasta
# HTF_10refs.fasta
