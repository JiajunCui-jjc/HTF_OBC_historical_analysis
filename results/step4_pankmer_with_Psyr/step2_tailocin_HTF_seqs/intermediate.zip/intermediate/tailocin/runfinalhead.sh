grep '^>' final_tailocin_all53_above98percentcov.fa \
| awk -F'qcov=' '{
    q=$2; sub(/\|.*/,"",q);   # keep only the number after qcov=
    print q "\t" $0
  }' \
| sort -k1,1gr \
| cut -f2- > final_header.txt
