for f in ./*.fa; do
  out="${f%.fa}.one.fa"
  echo "[*] Converting $f to $out"
  awk '/^>/ {if (seq) print seq; print; seq=""; next} {seq=seq $0} END {print seq}' "$f" > "$out"
done
